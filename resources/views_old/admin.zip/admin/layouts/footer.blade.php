<footer class="footer text-center">
    Designed and Developed by <a href="#">Hypersoftmedia</a>.
</footer>